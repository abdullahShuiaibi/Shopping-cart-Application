		flag=getCookie("flag");
		if(flag =="true")
		{
			document.writeln("<td width='100' align=center><a href='logoff.html'>Login</a></td>");
		}
		else
			document.writeln("<td width='100' align=center><a href='login.html'>Login</a></td>");
	